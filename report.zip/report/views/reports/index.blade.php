@extends('layouts.app')

@section('content')

    <div class="container">
        <div class="row">
          <div class="col">
                <h2>Status report for {{$type}} </h2> 
                
                <div class="panel panel-default">
                    <div class="panel-heading">
                    </div>
                    <div class="panel-body">
                        <div id="donutchart" style="width:400; height:600;">
                
                        </div>
                    </div>
                </div>
                
  
          </div>
          <div class="col">
                <div class="row"> 
                    <div class="pull-left">
                        <h2 style="align:center;">{{$type}}</h2> 
                    </div>
                </div>
      
                <table class="table table-bordered">
                    <tr>
                        @foreach($header as $head)
                            <th> {{ $head }}</th>
                        @endforeach
            
                    </tr>
                    @foreach ($tabledata as $key => $inv)
                    <tr>
                            @foreach ($inv as $keys => $invs)
                                <td>{{ $invs }}</td>
                            @endforeach
                    </tr>
                    @endforeach
                </table>
            <br>
              
          </div>
        </div>
      </div>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

  <script type="text/javascript">
   var analytics = <?php echo $status; ?>

   google.charts.load('current', {'packages':['corechart']});

   google.charts.setOnLoadCallback(drawChart);

   function drawChart()
   {
    var data = google.visualization.arrayToDataTable(analytics);
    var options = {
        width: 550,
        height: 500,
        title : 'Percentage of  Paid, Canceled and Pending Status',
        titlePosition: 'none',
        legend: { position: 'top', alignment: 'center' },
        is3D: true
    };
    var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
    chart.draw(data, options);
   }
  </script>



@endsection