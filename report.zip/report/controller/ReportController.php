<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Invoice;
use DB;
use App\User;
use App\Order;

class ReportController extends Controller
{
      /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, $type)
    {

        if($type == 'orders'){
            $tabledata = Order::all()->toArray();
            $data = DB::table('orders')
                    ->select(
                    DB::raw('status as status'),
                    DB::raw('count(*) as number'))
                    ->groupBy('status')
                    ->get();

                    $array[] = ['Status', 'Number'];
                    foreach($data as $key => $value)
                    {
                     $array[++$key] = [$value->status, $value->number];
                    }
                    $header = array('No','Subject','Customer', 'Issue Date', 'Assigned', 'Status', 'Open Till');
                    $status =  json_encode($array);
                }
        else{
            $tabledata = Invoice::all()->toArray();
            $data = DB::table('invoices')
                    ->select(
                    DB::raw('invoice_no as invoice_no'),
                    DB::raw('count(*) as number'))
                    ->groupBy('invoice_no')
                    ->get()->toArray();

                    $array[] = ['Invoice_no', 'Number'];
                    foreach($data as $key => $value)
                    {
                     $array[++$key] = [$value->invoice_no, $value->number];
                    }
                    $header = array('No','customer','status');
                    $status =  json_encode($array);
        }
                

        return view('reports.index',compact('tabledata', 'status', 'header', 'type'))
                    ->with('i', ($request->input('page', 1) - 1) * 5);          
          
    }
}
